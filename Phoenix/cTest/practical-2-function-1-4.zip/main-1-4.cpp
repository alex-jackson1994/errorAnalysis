#include <iostream>

extern int print_scaled_matrix(int array[3][3],int scale);               // this tells C++ that this function is defined elsewhere

int main()
{
  int scale = 3 ;
  int threebythree[3][3] = {{0,1,2},{3,4,5},{6,7,8}} ;
  print_scaled_matrix(threebythree,scale) ;

  //  int arrayT[10][10] = {{1,0,0,},{4,5,6},{7,8,9}};
  //int arrayF
  
  // std::cout << "zeros: " << count_numbers(array0) << std::endl;
  // std::cout << "OffDiagFail: " << identity(arrayOffDiagFail) << std::endl;
  //std::cout << "Pass: " << identity(arrayPass) << std::endl;

  //std::cout << "False: " << diagonal(arrayF) << std::endl;

}
