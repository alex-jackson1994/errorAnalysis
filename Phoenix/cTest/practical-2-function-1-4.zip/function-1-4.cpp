// 1-4 Given a matrix, print out the scaled version of the matrix, where you multiple every element in the matrix by the same numeric value. Elements should be printed by row, with a space separating elements on a row, and a newline character separating rows.

// Example:

// int scale = 3 ;
// int threebythree[3][3] = {{0,1,2},{3,4,5},{6,7,8}} ;
// print_scaled_matrix(threebythree,scale) ;
// This should produce the following output:
// 0 3 6
// 9 14 15
// 18 21 24
// Signature: void print_scaled_matrix(int array[3][3],int scale)
#include <iostream>

void print_scaled_matrix(int array[3][3],int scale)

{
  int sc_matrix[3][3] = {};
  for (int i = 0; i<3; i++)
    {
      for (int j=0; j<3; j++)
	{
	  sc_matrix[i][j] = array[i][j] * scale; //first [] is rows, second [] is columns
	}
    }

  // for loop for printing the scaled matrix
  // two parts - printing the number, and making a new line
  for (int i = 0; i<3; i++)
    {
      for (int j=0; j<3; j++)
	{
	  std::cout << sc_matrix[i][j];
	  if (j!=2) // i.e. not the last column
	    {
	      std::cout << " ";
	    }
	  else // i.e. the last column, make line break
	    {
	      std::cout << std::endl;
	    }
	 
	}
    }
}

